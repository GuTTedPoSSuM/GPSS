
document.getElementById('stakeButton').onclick = function() {
    const address = '0x57CBA93A8f0abC01695917BD1c3cF569217Ab203';
    window.location.href = `ethereum:${address}`;
}
