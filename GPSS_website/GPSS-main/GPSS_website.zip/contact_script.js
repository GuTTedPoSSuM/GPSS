
document.getElementById('contactForm').onsubmit = function(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;
    window.location.href = `mailto:guttedpossum@gmail.com?subject=Contact%20Form&body=${encodeURIComponent(message)}`;
}
